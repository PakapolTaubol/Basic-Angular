import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterOutlet } from '@angular/router';
import { PokemonService } from './pokemon.service';
import { HttpClientModule } from '@angular/common/http';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, RouterOutlet, HttpClientModule],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent implements OnInit {
  title = 'pokemon-search';
  inputText: string = '';
  pokemonList: any[] = [];
  pokemonFiltered: any[] = [];

  constructor(private pokemonService: PokemonService) {}

  fetchPokemon(): void {
    this.pokemonService.fetchPokemonData().subscribe((pokemonData) => {
      this.pokemonList = pokemonData;
      this.pokemonFiltered = this.pokemonList;
    })
  }

  searchOn(text: string): void {
    text ? this.inputText = text : this.inputText = ''
    this.filterPokemon(text);
  }

  filterPokemon(text: string): void {
    if (!text) {
      this.pokemonFiltered = this.pokemonList;
    }
    const lowercaseText = text.toLowerCase();
    this.pokemonFiltered = this.pokemonList.filter(pokemon => pokemon.name.toLowerCase().includes(lowercaseText));
  }

  ngOnInit(): void {
    this.fetchPokemon();
  }
}
